package com.mycompany.myapp;

public class Ngaythu
{
	private String thu,url;
	private int x,y;

	public Ngaythu(String thu, String url, int x, int y)
	{
		this.thu = thu;
		this.url = url;
		this.x = x;
		this.y = y;
	}

	public Ngaythu(String thu, String url)
	{
		this.thu = thu;
		this.url = url;
	}
	public Ngaythu(){
		
	}

	public void setX(int x)
	{
		this.x = x;
	}

	public int getX()
	{
		return x;
	}

	public void setY(int y)
	{
		this.y = y;
	}

	public int getY()
	{
		return y;
	}

	public void setThu(String thu)
	{
		this.thu = thu;
	}

	public String getThu()
	{
		return thu;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public String getUrl()
	{
		return url;
	}
	
}
