package com.mycompany.myapp;
import android.webkit.*;
import android.os.*;
import android.app.*;
import android.widget.*;
import android.view.*;

public class Main2Activity extends Activity 
{
	WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
		webView.setClickable(false);
		float scale = 280 * webView.getScale();
		webView.setInitialScale((int)scale);
		load();requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);	
		setContentView(webView);
    }
	
	public void load(){
		String ngaythu = getIntent().getExtras().getString("ngaythu");
		String url = getIntent().getExtras().getString("url");
		int x = getIntent().getExtras().getInt("x");
		int y = getIntent().getExtras().getInt("y");
		webView.loadUrl(url);
		webView.setScrollX(x);
		webView.setScrollY(y);
		//Toast.makeText(this,ngaythu,Toast.LENGTH_LONG).show();
		
	}
}
