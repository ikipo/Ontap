package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.content.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	Button t2,t3,t4,t5,t6,t7,t8;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState); 
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);	
		setContentView(R.layout.main);
		t2 = (Button)findViewById(R.id.mainButton2);
		t3 = (Button)findViewById(R.id.mainButton3);
		t4 = (Button)findViewById(R.id.mainButton4);
		t5 = (Button)findViewById(R.id.mainButton5);
		t6 = (Button)findViewById(R.id.mainButton6);
		t7 = (Button)findViewById(R.id.mainButton7);
		t8 = (Button)findViewById(R.id.mainButton8);
		t2.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				Ngaythu t2 = new Ngaythu("thu hai","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/thu-hai.html",1300,1900);
				loadNgaythu(t2);
			}
		});
		t3.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Ngaythu t3 = new Ngaythu("thu ba","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/thu-ba.html",1900,1900);
					loadNgaythu(t3);
				}
		});
		t4.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Ngaythu t4 = new Ngaythu("thu tu","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/thu-tu.html",1300,1900);
					loadNgaythu(t4);
				}
			});
		t5.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Ngaythu t5 = new Ngaythu("thu nam","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/thu-nam.html",1300,1900);
					loadNgaythu(t5);
				}
			});
		t6.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Ngaythu t6 = new Ngaythu("thu sau","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/thu-sau.html",1900,1900);
					loadNgaythu(t6);
				}
			});
		t7.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Ngaythu t7 = new Ngaythu("thu bay","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/thu-bay.html",1239,1900);
					loadNgaythu(t7);
				}
			});
		t8.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Ngaythu chunhat = new Ngaythu("chu nhat","https://www.minhngoc.net.vn/ket-qua-xo-so/mien-nam/chu-nhat.html",1300,2100);
					loadNgaythu(chunhat);
				}
			});
		
    }
	
	public void loadNgaythu(Ngaythu ngaythu){
		Bundle b = new Bundle();
		b.putString("ngaythu",ngaythu.getThu());	
		b.putString("url",ngaythu.getUrl());
		b.putInt("x",ngaythu.getX());
		b.putInt("y",ngaythu.getY());
		Intent i = new Intent(MainActivity.this,Main2Activity.class);
		i.putExtras(b);
		startActivity(i);
	}
}
