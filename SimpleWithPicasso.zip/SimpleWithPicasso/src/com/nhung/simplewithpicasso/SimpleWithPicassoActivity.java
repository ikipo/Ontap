package com.nhung.simplewithpicasso;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.squareup.picasso.Picasso;

public class SimpleWithPicassoActivity extends Activity
{

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ImageView imageView = (ImageView)findViewById(R.id.imageView);
        String url = "https://images-na.ssl-images-amazon.com/images/I/81Xd8Ah8HKL._SY355_.png";
        Picasso.with(this)
        		.load(url)
        		.into(imageView);
  }
}
