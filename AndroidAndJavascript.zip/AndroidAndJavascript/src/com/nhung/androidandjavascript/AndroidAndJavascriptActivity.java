package com.nhung.androidandjavascript;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.Context;
import android.content.DialogInterface.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.lang.Exception;
import com.nhung.androidandjavascript.IJavascriptHandler;
import android.webkit.JavascriptInterface;

public class AndroidAndJavascriptActivity extends Activity
{

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        try {
        WebView webView = new WebView (this);
        //WebView webView = (WebView)findViewById(R.id.webView);
        webView.loadUrl("file:///android_asset/index.html");
        webView.getSettings().setJavaScriptEnabled(true);
        User user = new User(this);   
        webView.addJavascriptInterface(user,"user");
        webView.loadUrl ("javascript:showId (some)");
        setContentView(webView);
        }catch (Exception e) {
        Toast.makeText (this,e.getMessage()+"",Toast.LENGTH_LONG).show ();
        }
                    
    }
    

class User {
Context c;
public User (Context c){
this.c = c;
}
@android.webkit.JavascriptInterface
public String showUser (){
return "Hello Yo!";
}

@android.webkit.JavascriptInterface
public void toAndroid (String text){
Toast.makeText(c,text,Toast.LENGTH_SHORT).show ();
}
}
}

