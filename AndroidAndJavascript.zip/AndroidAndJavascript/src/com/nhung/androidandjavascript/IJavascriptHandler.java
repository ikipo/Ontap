package com.nhung.androidandjavascript;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.content.Context;

public class IJavascriptHandler
{
private Context c;
	public IJavascriptHandler(Context c)
	{
	this.c = c;
	}
	
	// This annotation is required in Jelly Bean and later:
   @JavascriptInterface
   public void sendToAndroid(String text) {
      // this is called from JS with passed value
      Toast t = Toast.makeText(c, text, 2000);
      t.show();
   }
}
