package com.mycompany.myapp;

public class User
{
	private int id;
	private String name, pass;

	public User(String name, String pass)
	{
		this.name = name;
		this.pass = pass;
	}
	public User()
	{}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public void setPass(String pass)
	{
		this.pass = pass;
	}

	public String getPass()
	{
		return pass;
	}
	
}
