package com.mycompany.myapp;
import android.database.sqlite.*;
import android.content.*;

public class Database extends SQLiteOpenHelper
{
	public Database(Context c){
		super(c,"data.db",null,1);
	}

	@Override
	public void onCreate(SQLiteDatabase p1)
	{
		// TODO: Implement this method
		String sql = "create table admin(id integer primary key autoincrement,name text,pass text)";
		p1.execSQL(sql);
		sql = "create table user(id integer primary key autoincrement, name text, pass text)";
		p1.execSQL(sql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase p1, int p2, int p3)
	{
		// TODO: Implement this method
	}


	
}
