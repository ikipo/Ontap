package com.mycompany.myapp;
import android.content.*;
import android.database.sqlite.*;
import android.database.*;
import java.util.*;

public class AdminDAO extends Database
{
	public AdminDAO(Context c){
		super(c);
	}
	
	public void add(User ad){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("name",ad.getName());
		values.put("pass",ad.getPass());
		db.insert("Admin",null,values);
		db.close();
	}
	
	public List <User> getDataBySql(String sql){
		List <User> list = new ArrayList <>();
		User ad = new User();
		SQLiteDatabase db = getReadableDatabase();
		Cursor c = db.rawQuery(sql,null);
		if(c!=null){
			c.moveToFirst();
			do{
				int id = c.getInt(0);
				String name = c.getString(1)+"";
				String pass = c.getString(2)+"";
				ad.setId(id);
				ad.setName(name);
				ad.setPass(pass);
				list.add(ad);
			}while(c.moveToNext());
		}
		db.close();
		return list;
	}
	
	public List <User> getAll(){
		return getDataBySql("select * from Admin");
	}
	
	public void update(User ad){
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("name",ad.getName());
		values.put("pass",ad.getPass());
		db.update("Admin",values,"id like '"+ad.getId()+"'",null);
		db.close();
	}
	
	public void delete(int id){
		SQLiteDatabase db = getWritableDatabase();
		db.delete("","",null);
	}
	
	public void demo(){
		User ad1 = new User("1a","aaa");
		User ad2 = new User("2a","aaa");
		User ad3 = new User("3a","aaa");
		User ad4 = new User("4a","aaa");
		User ad5 = new User("5a","aaa");
		User ad6 = new User("6a","aaa");
		User ad7 = new User("7a","aaa");
		User ad8 = new User("8a","aaa");
		add(ad1);add(ad2);add(ad3);add(ad4);add(ad5);add(ad6);add(ad7);
		add(ad8);
	}
	
	public int getCount(){
		return getAll().size();
	}
}
